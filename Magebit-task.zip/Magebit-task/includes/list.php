<style>
    th,td{
        text-align: left;
        padding: 5px;
    }
</style>

<table  width="1000px" align="center" border> 

<tr>
<th>Select</th>
    <th>Id</th>
   
    <th>Email</th>
    <th>Date Added</th>

</tr>

<?php 
    foreach($emails as $email):
        ?>
<tr>
<td><input type="checkbox" name='ids[<?= $email['id'] ?>]' value="<?=  $email['id'] ?>"></td>
    <td><?= $email['id'] ?></td>
   
    <td><?= $email['email'] ?></td>
    <td><?= $email['created_at'] ?></td>
</tr>
        <?php 
    endforeach;

?>



</table>
<style>
 .pagination {
     text-align: center;
     margin-top: 50px;
     margin-bottom: 100px;
 }
    .pagination a{
        display: inline-block;
        padding: 5px 10px;
        background-color: #ccc;
        color: #000;
        text-decoration: none;
        margin: 5px;
        border-radius: 5px;
        cursor: pointer;



    }
</style>
<div class="pagination">
    <?php for($i=0;$i<$pagination;$i++ ): ?>
            <a onclick="callPage(<?= $i ?>)"><?= $i+1 ?></a>
    <?php endfor; ?>

    </div>


    <script>

            function callPage(page){
                order_by=document.getElementById("sort").value;
                provider=document.getElementById("provider").value;

                
                url='process_email.php?action=list&order_by='+order_by+'&provider='+provider+'&page='+page;
                console.log(url);
                window.location.href= url;

            }
            function callList(){
                
                order_by=document.getElementById("sort").value;
                provider=document.getElementById("provider").value;

                
                url='process_email.php?action=list&order_by='+order_by+'&provider='+provider+'&page=0';

                window.location.href= url;

            }

          
function post(path, params, method='post') {

const form = document.createElement('form');
form.method = method;
form.action = path;

for (const key in params) {
  if (params.hasOwnProperty(key)) {
    const hiddenField = document.createElement('input');
    hiddenField.type = 'hidden';
    hiddenField.name = key;
    hiddenField.value = params[key];

    form.appendChild(hiddenField);
  }
}

document.body.appendChild(form);
form.submit();
}



function deleteEmails(){



var array = []
var checkboxes = document.querySelectorAll('input[type=checkbox]:checked')

for (var i = 0; i < checkboxes.length; i++) {
  array.push(checkboxes[i].value)
}
deleteIds=array.toString();
//HttpRequest("process_email.php?action=delete", method="post", data="yourkey="+deleteIds);
if(confirm("Do you want to delete these records?")){
    post('process_email.php?action=delete',{ids:deleteIds})
}


}

function  exportCSV(){



var array = []
var checkboxes = document.querySelectorAll('input[type=checkbox]:checked')

for (var i = 0; i < checkboxes.length; i++) {
  array.push(checkboxes[i].value)
}
deleteIds=array.toString();


    post('process_email.php?action=export',{ids:deleteIds})


}

function onactionChange(){
    action=document.getElementById('action').value;

if(action==1){
    exportCSV();
}
    if(action==2){
        deleteEmails();
    }
    
}



    </script>