<html>
    <head>
        <title>Newsletter Managment - By Jalaal</title>
        <style>
            label{
                margin-bottom: 10px;
                display: block;
            }
            </style>
    </head>
    <body>
    
          <center><h1>Newsletter Managment</h1></center>
            <hr>
            <table width="1000px" align="center"> 

                <tr>
                    <td width="33%">
                            <label>Sort Emails</label>
                                <?php $order_by=2; if(isset($_GET['order_by'])):
                                    $order_by=$_GET['order_by'];
                              
                                
                                endif; ?>
                             <select id="sort" onchange="callList()">
                                    <option value="0" <?php if($order_by==0){ echo "selected"; } ?>)>Sort by A-Z</option>
                                    <option value="1" <?php if($order_by==1){ echo "selected"; } ?>>Sort by Z-A</option>
                                    <option value="2" <?php if($order_by==2){ echo "selected"; } ?> >Sort by Date Created</option>

                             </select>   
                
                        </td>
                    <td width="33%" >
                        <label> By Providers</label>
                     
                         <select name="provider" id="provider" onchange="callList()">
                         <?php $getprovider=''; 
                         if(isset($_GET['provider'])): 
                            $getprovider=trim($_GET['provider']);
                           
                          endif; ?>
                                 <option value="All" <?php if($getprovider=='All'):  echo "selected"; endif; ?>>All</option>
                                 
                                 <?php foreach($providers as $provider): ?>
                                 <option value="<?= $provider['provider'] ?>" echo  <?php if($getprovider==$provider['provider']):  echo "selected"; endif; ?>> <?= $provider['provider']   ?> </option>
                                 <?php endforeach; ?>
                        </select>
                </td>

                <td >
                    <label>
                        Action
                    </label>
                    <select onchange="onactionChange()" id="action">
                    <option >Choose Action</option>
                        <option value="1">Export selected to CSV</option>    
                        <option value="2">Delete Selected</option>

                    </select>
                </td>
                  


                </tr>



            </table>


<hr>
<br>

<?php if(isset($_GET['message'])): ?>
<center><h3 style="color:green;"><?= $_GET['message'] ?></h3></center>
<?php endif; ?>
<br>
            <?php 

                include('list.php');

            ?>

           
    </body>

</html>