<?php 

Class EmailNewsletter{

        private $email="";
        private $mysqli="";
        private $server="localhost";
        private $user ="root";
        private $password ="";
        private $database="newletter";
        private $message=array();
        

        function __construct() {
            //create database

         

            $this->mysqli = new mysqli($this->server,$this->user,$this->password,$this->database);

            if ($this->mysqli->connect_errno) {
                echo "Failed to connect to MySQL: " . $this->mysql->connect_error;
                exit();
              }
        }



        public function exportCSV($data){
            
            if(!empty($data)):

            $result=$this->mysqli->query("select * from emails where id IN($data)");

            $header=array("ID","Email","Date Created");
            $rows=$result->fetch_all(MYSQLI_ASSOC);

            header("Content-type: text/csv");
            header("Content-Disposition: attachment; filename=file.csv");
            header("Pragma: no-cache");
            header("Expires: 0");
            echo "ID,Email,Date Created\n";
            foreach($rows as $row):
              echo $row['id'].",".$row['email'].','.$row['created_at']."\n";  
            endforeach;

            die;
        else:
            echo "No record selected!";
        endif;
         
        }

        public function pagination($total_rows,$records=10){

            
            $total_pages=ceil($total_rows / $records);

            return $total_pages;




        }   

        public function selectProvider(){
              $result=  $this->mysqli->query("select DISTINCT SUBSTRING_INDEX(email,'@',-1) provider from emails");

              return $result->fetch_all(MYSQLI_ASSOC);
         
        }

        public function list($condition,$page=0,$records=10){
           
            $start= $records*($page);
            
           $query= "select * from emails ";

            if(isset($condition['provider'])){

                $query.=" where email like '%@".$condition['provider']."' ";
            }

           if(isset($condition['order_by'])){
                
            if($condition['order_by']==0):
                $order_by="email ASC";
            elseif($condition['order_by']==1):
                $order_by="email DESC";
            elseif($condition['order_by']==2):
                $order_by="created_at ASC";
            endif;

                $query.=' Order By '. $order_by.' ';
           }

           $all_data_result=$this->mysqli->query($query);


           $query.= " limit $start,  $records";

         //  echo $query;
         
        $result=    $this->mysqli->query($query);
          
        
        $data['result']= $result->fetch_all(MYSQLI_ASSOC);
        $data['pagination']=$this->pagination($all_data_result->num_rows);
       
        return $data;

        }

        public function addEmail($email){

            if($this->isValidEmail($email)){
                 
                $this->email=$this->mysqli->real_escape_string($email);

                $result=$this->mysqli->query("select * from emails where email='".$this->email."'");
                
                if($result->num_rows>0){
                    $this->message=array('type'=>'Error','message'=>'Entered email already exist');
                }else{


                    if( $this->mysqli->query("Insert into emails (email) values('".$this->email."')")){
                        $this->message=array('type'=>'Success','message'=>'Email inserted Successfuly');
                    }else{
    
                        $this->message=array('type'=>'Error','message'=>"We can't add email at this moment. Server Error");
                    }


                }

               
            

            }else{
                $this->message=array('type'=>'Error','message'=>'Enter an valid email address');
                
              

            }
         
            echo json_encode($this->message,JSON_FORCE_OBJECT);

        }

        private function isValidEmail($email){ 
            return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
        }

        public function delete($ids){
            if($this->mysqli->query("delete from emails where id IN($ids)")):
                return true;
            else:
                return false;
            endif;   
            

        }
}

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$newsletter= new EmailNewsletter();

$providers=$newsletter->selectProvider();

//var_dump($_POST);

$action= $_REQUEST['action'];

switch($action){


    case 'add':
       
        $newsletter->addEmail($_POST['email']);
        break;

    case 'list':
        $page=0;
        $records=10;
        $condition=array();
        if(isset($_REQUEST['page'])){
            $page=$_REQUEST['page'];
        }

        if(isset($_REQUEST['records'])){
            $page=$_REQUEST['records'];
        }

        if(isset($_REQUEST['order_by'])){
            $condition['order_by']=$_REQUEST['order_by'];

        }

        if(isset($_REQUEST['provider'])){
            if($_REQUEST['provider']=='All'){
                $condition['provider']='%';
            }else{
                $condition['provider']=$_REQUEST['provider'];
            }
            
            
        }

        $data=$newsletter->list($condition,$page,$records);
        $emails=$data['result'];
        $pagination=$data['pagination'];
       // var_dump($emails);
        include('includes/template.php');
        break;

        case 'delete':
            if(isset($_POST['ids'])):
                $ids=$_POST['ids'];
                if($newsletter->delete($ids)):
                    header("Location: process_email.php?action=list&message=Records deleted successfully");
                endif;
            else:
                echo "No record selected!";
            endif;
            break;

            case "export":

            if(isset($_POST['ids'])):
                $ids=$_POST['ids'];
                $newsletter->exportCSV($ids);
            else:
                echo "No action found!";

            endif;
                break;
}



?>