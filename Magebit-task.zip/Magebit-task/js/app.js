window.onload = function() {
    subheight= document.getElementById('subscribeBox').clientHeight;
    console.log(subheight);
  topval=  (window.innerHeight/2)-(subheight/2)+80;
  console.log(window.innerHeight);
    document.getElementById('subscribeBox').style.top=topval;
  };

window.onresize=function(){
    subheight= document.getElementById('subscribeBox').clientHeight;
    console.log(subheight);
  topval=  (window.innerHeight/2)-(subheight/2)+80;
  console.log(window.innerHeight);
    document.getElementById('subscribeBox').style.top=topval; 
}

  function emailFocus(){

    document.getElementById("subscribe-box-wrap").classList.add('input-box-shadow');
  }

  function emailFocusOut(){
    document.getElementById("subscribe-box-wrap").classList.remove('input-box-shadow');

  }


function emailValid(inputText)
{
	if (/\S+@\S+\.\S+/.test(inputText))
  {
      
    return (true)
  }
   
    return (false)
}



function termsCheked() {
    var term = document.getElementById("subscribeterms");
    if (term.checked) {
     return true;
    } else {
      return false;
    }
  }

  function emailValidation(){
    document.getElementById('error').innerHTML="";

    email= document.getElementById('emailBox').value;
    if(email.length>0){
    if(emailValid(email)){

        if(email.substr(email.length - 3)=='.co'){
            document.getElementById('error').innerHTML="We are not accepting subscriptions from Colombia emails";
            return false;
        }
        if(!termsCheked()){
            document.getElementById('error').innerHTML="You must accept the terms and conditions";
            return false;
        }

        return true;
        




    }else{

        document.getElementById('error').innerHTML="Please provide a valid e-mail address";
        return false;

    }

}else{

    document.getElementById('error').innerHTML="Email address is required!";
    return false;
}

    


  }



  function submitEmalForm(){
    email= document.getElementById('emailBox').value;
   
  

    if( emailValidation()){

        sendData(email);
    }
       
    document.getElementById("submitForm").disabled=false;

  }


  function sendData( email ) {
  
    document.getElementById("submitForm").disabled=true;
  
    const XHR = new XMLHttpRequest();
  
    let urlEncodedData = "",
        urlEncodedDataPairs = [];
  
        urlEncodedDataPairs.push( encodeURIComponent( 'email' ) + '=' + encodeURIComponent(email ) );
        urlEncodedDataPairs.push( encodeURIComponent( 'action' ) + '=' + encodeURIComponent('add' ) );
        urlEncodedData = urlEncodedDataPairs.join( '&' ).replace( /%20/g, '+' );
  

    


    XHR.onreadystatechange = function() {
        if (XHR.readyState === 4) {
          //  formcallback(xhr.response);
   

            xresponse= JSON.parse(XHR.response);
       
         if(xresponse.type=='Success'){

            document.getElementById('subscribeform').innerHTML="";
            document.getElementById('success_image').innerHTML="<img src='images/trofphy.svg' />";
            document.getElementById('heading').innerHTML="Thanks for subscribing!";
            document.getElementById('message').innerHTML="You have successfully subscribed to our email listing. <br> Check your email for the discount code.";


         }
         if(xresponse.type=='Error'){
          document.getElementById("error").innerHTML=xresponse.message;
         }
       


          }
    };

    XHR.addEventListener( 'error', function(event) {
      alert( 'Oops! Something went wrong.' );
      document.getElementById("submitForm").disabled=false;
    } );

    XHR.open( 'POST', 'process_email.php' );
    XHR.setRequestHeader( 'Content-Type', 'application/x-www-form-urlencoded' );
  
  
    XHR.send( urlEncodedData );
  }
  

  